# Automotive-Sub-Ghz-
A Collection of Various Automotive Sub-Ghz Key Fobs for Research Purposes Only!

FILE KEY:
l = lock /
u = Unlock /
rs = Remote Start /
t = trunk /
p = panic button /
sd = side door (auto sliding doors)

the number denotes times pressed (usualy twice per button)

i encounter newer cars daily. Also if there is a better/perfered format for collection please let me know. 







